package logging;

public class InfoHandler {

}
