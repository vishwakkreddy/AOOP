package logging;

public class ErrorHandler {

}
