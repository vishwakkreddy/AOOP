package logging;

public class DebugHandler {

}
