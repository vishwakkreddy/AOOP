package logging;

public class LogCommand {

}
