package logging;
public enum LogLevel {
    INFO,
    DEBUG,
    ERROR
}
