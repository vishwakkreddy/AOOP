package logging;
import java.util.ArrayList;
import java.util.List;

// Abstract LogHandler class
abstract class LogHandler {
    protected LogHandler nextHandler;

    public void setNextHandler(LogHandler nextHandler) {
        this.nextHandler = nextHandler;
    }

    public abstract void handleRequest(String message, String level);
}

// Concrete LogHandler implementations
class InfoHandler extends LogHandler {
    @Override
    public void handleRequest(String message, String level) {
        if ("INFO".equalsIgnoreCase(level)) {
            System.out.println("InfoHandler: " + message);
        } else if (nextHandler != null) {
            nextHandler.handleRequest(message, level);
        }
    }
}

class DebugHandler extends LogHandler {
    @Override
    public void handleRequest(String message, String level) {
        if ("DEBUG".equalsIgnoreCase(level)) {
            System.out.println("DebugHandler: " + message);
        } else if (nextHandler != null) {
            nextHandler.handleRequest(message, level);
        }
    }
}

class ErrorHandler extends LogHandler {
    @Override
    public void handleRequest(String message, String level) {
        if ("ERROR".equalsIgnoreCase(level)) {
            System.out.println("ErrorHandler: " + message);
        } else if (nextHandler != null) {
            nextHandler.handleRequest(message, level);
        }
    }
}

// Command interface
interface Command {
    void execute(String message, String level);
}

// LogCommand class
class LogCommand implements Command {
    private LogHandler handler;

    public LogCommand(LogHandler handler) {
        this.handler = handler;
    }

    @Override
    public void execute(String message, String level) {
        handler.handleRequest(message, level);
    }
}

// Main class to demonstrate the implementation
public class Client {
    public static void main(String[] args) {
        // Set up handlers
        LogHandler infoHandler = new InfoHandler();
        LogHandler debugHandler = new DebugHandler();
        LogHandler errorHandler = new ErrorHandler();

        infoHandler.setNextHandler(debugHandler);
        debugHandler.setNextHandler(errorHandler);

        // Create commands
        List<Command> commands = new ArrayList<>();
        commands.add(new LogCommand(infoHandler));
        commands.add(new LogCommand(debugHandler));
        commands.add(new LogCommand(errorHandler));

        // Execute commands with test messages
        commands.get(0).execute("This is an info message.", "INFO");
        commands.get(1).execute("This is a debug message.", "DEBUG");
        commands.get(2).execute("This is an error message.", "ERROR");
    }
}
