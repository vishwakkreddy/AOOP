package logging;

import java.util.Iterator;
import java.util.List;

public class Logger {
    private final List<Command> commands;

    public Logger(List<Command> commands) {
        this.commands = commands;
    }

    public void processCommands() {
        Iterator<Command> iterator = commands.iterator();
        while (iterator.hasNext()) {
            Command command = iterator.next();
            command.execute("Processing log message", LogLevel.INFO); // Default example level
        }
    }
}
