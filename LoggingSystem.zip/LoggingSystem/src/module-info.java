/**
 * 
 */
/**
 * 
 */
module LoggingSystem {
}