package game.factories;

import game.items.EasyPowerUp;
import game.items.EasyWeapon;
import game.items.PowerUp;
import game.items.Weapon;

public class EasyLevelFactory implements AbstractFactory {
    public Weapon createWeapon() {
        return new EasyWeapon();
    }

    public PowerUp createPowerUp() {
        return new EasyPowerUp();
    }
}
