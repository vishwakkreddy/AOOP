package game.factories;

import game.items.HardPowerUp;
import game.items.HardWeapon;
import game.items.PowerUp;
import game.items.Weapon;

public class HardLevelFactory implements AbstractFactory {
    public Weapon createWeapon() {
        return new HardWeapon();
    }

    public PowerUp createPowerUp() {
        return new HardPowerUp();
    }
}
