package game.factories;

import game.items.MediumPowerUp;
import game.items.MediumWeapon;
import game.items.PowerUp;
import game.items.Weapon;

public class MediumLevelFactory implements AbstractFactory {
    public Weapon createWeapon() {
        return new MediumWeapon();
    }

    public PowerUp createPowerUp() {
        return new MediumPowerUp();
    }
}
