package game.factories;

import game.items.PowerUp;
import game.items.Weapon;

public interface AbstractFactory {
    Weapon createWeapon();
    PowerUp createPowerUp();
}
