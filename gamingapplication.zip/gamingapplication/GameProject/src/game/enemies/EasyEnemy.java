package game.enemies;

public class EasyEnemy implements Enemy {
    public String attack() {
        return "Easy Enemy attacks with low damage!";
    }
}