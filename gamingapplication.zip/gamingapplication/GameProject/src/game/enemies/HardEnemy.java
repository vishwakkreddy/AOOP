package game.enemies;

public class HardEnemy implements Enemy {
    public String attack() {
        return "Hard Enemy attacks with high damage!";
    }
}
