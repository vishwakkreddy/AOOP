package game.items;

public class MediumPowerUp implements PowerUp {
    public String activate() {
        return "Medium Power-Up activated: Moderate boost!";
    }
}
