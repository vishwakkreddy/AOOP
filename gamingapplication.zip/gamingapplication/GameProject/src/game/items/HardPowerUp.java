package game.items;

public class HardPowerUp implements PowerUp {
    public String activate() {
        return "Hard Power-Up activated: High boost!";
    }
}
