package game.items;

public class EasyPowerUp implements PowerUp {
    public String activate() {
        return "Easy Power-Up activated: Low boost!";
    }
}
