package game.items;

public class HardWeapon implements Weapon {
    public String use() {
        return "Using the most advanced weapon!";
    }
}
