package gameapplication;

import game.state.GameState;
import game.factory.*;
import game.entities.*;

public class GameApplication {
    public static void main(String[] args) {
        GameState gameState = GameState.getInstance();
        gameState.setDifficulty("Hard");

        AbstractGameFactory gameFactory = gameState.getDifficulty().equals("Easy")
                ? new EasyGameFactory()
                : new HardGameFactory();

        Weapon weapon = gameFactory.createWeapon();
        PowerUp powerUp = gameFactory.createPowerUp();

        EnemyFactory enemyFactory = new ZombieFactory();
        Enemy enemy = enemyFactory.createEnemy();

        System.out.println("Level: " + gameState.getCurrentLevel());
        weapon.use();
        powerUp.activate();
        enemy.attack();

        gameState.nextLevel();
        System.out.println("Next Level: " + gameState.getCurrentLevel());
    }
}
