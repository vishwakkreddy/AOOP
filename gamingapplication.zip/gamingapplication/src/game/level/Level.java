package game.level;

import java.util.List;
import game.entities.Enemy;
import game.entities.PowerUp;

public class Level {
    private int levelNumber;
    private List<Enemy> enemies;
    private List<PowerUp> powerUps;

    public Level(int levelNumber, List<Enemy> enemies, List<PowerUp> powerUps) {
        this.levelNumber = levelNumber;
        this.enemies = enemies;
        this.powerUps = powerUps;
    }

    public int getLevelNumber() {
        return levelNumber;
    }

    public List<Enemy> getEnemies() {
        return enemies;
    }

    public List<PowerUp> getPowerUps() {
        return powerUps;
    }
}
