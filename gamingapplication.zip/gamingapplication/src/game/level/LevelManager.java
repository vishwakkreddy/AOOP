package game.level;

public class LevelManager {
    public Level loadLevel(int levelNumber) {
        // Simplified level loading logic
        System.out.println("Loading Level: " + levelNumber);
        return new Level(levelNumber, null, null); // Populate with actual enemies and power-ups
    }

    public void resetLevel() {
        System.out.println("Level reset.");
    }
}
