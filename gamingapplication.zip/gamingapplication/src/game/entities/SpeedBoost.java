package game.entities;

public class SpeedBoost extends PowerUp {
    @Override
    public void activate() {
        System.out.println("Increasing speed for a short duration!");
    }
}
