package game.entities;

public abstract class Enemy {
    public abstract void attack();
}

