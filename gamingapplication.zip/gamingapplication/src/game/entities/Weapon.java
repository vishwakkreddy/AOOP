package game.entities;

public abstract class Weapon {
    public abstract void use();
}
