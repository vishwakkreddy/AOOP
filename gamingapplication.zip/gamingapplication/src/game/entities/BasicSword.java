package game.entities;

public class BasicSword extends Weapon {
    @Override
    public void use() {
        System.out.println("Swinging a basic sword!");
    }
}
