package game.entities;

public class Zombie extends Enemy {
    @Override
    public void attack() {
        System.out.println("Zombie attacks with slow, powerful moves!");
    }
}
