package game.entities;

public class HealthPotion extends PowerUp {
    @Override
    public void activate() {
        System.out.println("Restoring health!");
    }
}
