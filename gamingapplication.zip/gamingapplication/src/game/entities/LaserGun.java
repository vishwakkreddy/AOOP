package game.entities;

public class LaserGun extends Weapon {
    @Override
    public void use() {
        System.out.println("Firing a laser gun!");
    }
}
