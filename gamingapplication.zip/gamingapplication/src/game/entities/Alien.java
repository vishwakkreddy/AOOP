package game.entities;

public class Alien extends Enemy {
    
    public void attack() {
        System.out.println("Alien attacks with fast, precise laser beams!");
    }
}
