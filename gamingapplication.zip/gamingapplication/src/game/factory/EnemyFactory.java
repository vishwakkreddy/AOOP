package game.factory;

import game.entities.Enemy;

public abstract class EnemyFactory {
    public abstract Enemy createEnemy();
}
