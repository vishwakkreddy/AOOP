package game.factory;


import game.entities.Weapon;
import game.entities.PowerUp;

public abstract class AbstractGameFactory {
    public abstract Weapon createWeapon();
    public abstract PowerUp createPowerUp();
}

