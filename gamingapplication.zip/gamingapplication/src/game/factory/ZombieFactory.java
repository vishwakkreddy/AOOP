package game.factory;



import game.entities.Enemy;
import game.entities.Zombie;

public class ZombieFactory extends EnemyFactory {
    @Override
    public Enemy createEnemy() {
        return new Zombie();
    }
}

