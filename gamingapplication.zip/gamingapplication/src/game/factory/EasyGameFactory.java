package game.factory;

import game.entities.Weapon;
import game.entities.PowerUp;
import game.entities.BasicSword;
import game.entities.HealthPotion;

public class EasyGameFactory extends AbstractGameFactory {
    @Override
    public Weapon createWeapon() {
        return new BasicSword();
    }

    @Override
    public PowerUp createPowerUp() {
        return new HealthPotion();
    }
}
