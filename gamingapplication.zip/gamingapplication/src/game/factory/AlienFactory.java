package game.factory;

import game.entities.Enemy;
import game.entities.Alien;

public class AlienFactory extends EnemyFactory {
    @Override
    public Enemy createEnemy() {
        return new Alien();
    }
}
