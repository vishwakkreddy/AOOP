package game.factory;

import game.entities.Weapon;
import game.entities.PowerUp;
import game.entities.LaserGun;
import game.entities.SpeedBoost;

public class HardGameFactory extends AbstractGameFactory {
    @Override
    public Weapon createWeapon() {
        return new LaserGun();
    }

    @Override
    public PowerUp createPowerUp() {
        return new SpeedBoost();
    }
}
