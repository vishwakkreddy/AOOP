/**
 * 
 */
/**
 * 
 */
module gamingapplication {
}