package dataimport;


public abstract class DataImporter {
    // Template method defining the steps of data import
    public final void importData(String filePath) {
        readData(filePath);
        parseData();
        validateData();
        saveData();
    }

    // Steps with default or abstract implementations
    protected abstract void readData(String filePath);

    protected abstract void parseData();

    protected void validateData() {
        System.out.println("Validating data...");
    }

    protected void saveData() {
        System.out.println("Saving data to database...");
    }
}
