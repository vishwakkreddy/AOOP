package dataimport;

public class JSONImporter extends DataImporter {
    @Override
    protected void readData(String filePath) {
        System.out.println("Reading JSON file: " + filePath);
    }

    @Override
    protected void parseData() {
        System.out.println("Parsing JSON data...");
    }
}

