package dataimport;

public class CSVImporter extends DataImporter {
   
    protected void readData(String filePath) {
        System.out.println("Reading CSV file: " + filePath);
    }

    @Override
    protected void parseData() {
        System.out.println("Parsing CSV data...");
    }
}

