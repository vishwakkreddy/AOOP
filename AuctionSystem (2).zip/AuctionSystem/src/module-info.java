/**
 * 
 */
/**
 * 
 */
module AuctionSystem {
}