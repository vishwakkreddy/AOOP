package auction;

public abstract class AuctionTemplate {
    public final void conductAuction() {
        notifyStart();
        auctionProcess();
        notifyEnd();
    }

    private void notifyStart() {
        System.out.println("Auction is starting...");
    }

    private void notifyEnd() {
        System.out.println("Auction has ended.");
    }

    protected abstract void auctionProcess();
}
