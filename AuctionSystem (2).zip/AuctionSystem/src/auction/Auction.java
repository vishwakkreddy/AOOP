package auction;

import java.util.ArrayList;
import java.util.List;

public class Auction implements Subject {
    private List<Observer> bidders = new ArrayList<>();
    private String auctionName;

    public Auction(String auctionName) {
        this.auctionName = auctionName;
    }

    @Override
    public void registerObserver(Observer observer) {
        bidders.add(observer);
    }

    @Override
    public void unregisterObserver(Observer observer) {
        bidders.remove(observer);
    }

    @Override
    public void notifyObservers(String message) {
        for (Observer bidder : bidders) {
            bidder.update(auctionName + ": " + message);
        }
    }

    public void startAuction() {
        notifyObservers("Auction has started.");
    }

    public void endAuction() {
        notifyObservers("Auction has ended.");
    }
}
