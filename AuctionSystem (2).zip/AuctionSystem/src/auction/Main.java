package auction;

public class Main {
   public static void main(String[] args) {
       // Observer Pattern Demo
       Auction auction = new Auction("Antique Auction");
       Observer bidder1 = new Bidder("Alice");
       Observer bidder2 = new Bidder("Bob");

       auction.registerObserver(bidder1);
       auction.registerObserver(bidder2);

       auction.startAuction();
       auction.endAuction();

       // Template Pattern Demo
       AuctionTemplate standardAuction = new StandardAuction();
       AuctionTemplate reserveAuction = new ReserveAuction();

       System.out.println("\nConducting Standard Auction:");
       standardAuction.conductAuction();

       System.out.println("\nConducting Reserve Auction:");
       reserveAuction.conductAuction();
   }
}
