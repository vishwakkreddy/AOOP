package auction;

public class StandardAuction extends AuctionTemplate {
    @Override
    protected void auctionProcess() {
        System.out.println("Standard auction process ongoing...");
    }
}
