package auction;

public interface Observer {
    void update(String message);
}
