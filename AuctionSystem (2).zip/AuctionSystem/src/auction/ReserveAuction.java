package auction;

public class ReserveAuction extends AuctionTemplate {
	
    protected void auctionProcess() {
        System.out.println("Reserve auction with minimum price ongoing...");
    }
}

