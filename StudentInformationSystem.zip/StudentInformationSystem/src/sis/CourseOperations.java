package sis;

public interface CourseOperations {
 void displayCourseDetails(Course course);
 void listEnrolledStudents(Course course);
}

