package sis;

public interface IStudentOperations {
 void displayStudentDetails(Student student);
 void listStudentCourses(Student student);
}
