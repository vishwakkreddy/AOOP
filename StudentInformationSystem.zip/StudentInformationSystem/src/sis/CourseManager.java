package sis;

import java.util.List;


public class CourseManager implements CourseOperations {

    
    public void displayCourseDetails(Course course) {
        System.out.println("Course Details: " + course.toString());
    }

    public void listEnrolledStudents(Course course) {
        List<Student> students = course.getEnrolledStudents();
        System.out.println("Students enrolled in " + course.getCourseName() + ":");
        for (Student student : students) {
            System.out.println(student.getName());
        }
    }
}
