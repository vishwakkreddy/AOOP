package sis;

public class MainClass {
    public static void main(String[] args) {
        // Create some student objects
        Student student1 = new Student("Alice", "S101", new String[]{"Math", "Science"});
        Student student2 = new Student("Bob", "S102", new String[]{"History", "Science"});
        
        // Create course objects
        Course math = new Course("C101", "Math");
        Course science = new Course("C102", "Science");
        
        // Enroll students
        EnrollmentManager enrollmentManager = new EnrollmentManager();
        enrollmentManager.enrollStudentInCourse(student1, math);
        enrollmentManager.enrollStudentInCourse(student2, science);
        
        // Create managers
        StudentManager studentManager = new StudentManager();
        CourseManager courseManager = new CourseManager();
        
        // Display student details
        studentManager.displayStudentDetails(student1);
        studentManager.listStudentCourses(student1);
        
        System.out.println();

        studentManager.displayStudentDetails(student2);
        studentManager.listStudentCourses(student2);

        System.out.println();

        // Display course details and enrolled students
        courseManager.displayCourseDetails(math);
        courseManager.listEnrolledStudents(math);

        courseManager.displayCourseDetails(science);
        courseManager.listEnrolledStudents(science);
    }
}

