package sis;

public class Student {
 private String name;
 private String studentId;
 private String[] coursesEnrolled;

 public Student(String name, String studentId, String[] coursesEnrolled) {
     this.name = name;
     this.studentId = studentId;
     this.coursesEnrolled = coursesEnrolled;
 }

 public String getName() {
     return name;
 }

 public String getStudentId() {
     return studentId;
 }

 public String[] getCoursesEnrolled() {
     return coursesEnrolled;
 }

 @Override
 public String toString() {
     return "Student Name: " + name + ", ID: " + studentId;
 }
}
