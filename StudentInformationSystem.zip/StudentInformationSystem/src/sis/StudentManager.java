package sis;

public class StudentManager implements IStudentOperations {

 @Override
 public void displayStudentDetails(Student student) {
     System.out.println("Student Details: " + student.toString());
 }

 @Override
 public void listStudentCourses(Student student) {
     System.out.println(student.getName() + " is enrolled in the following courses:");
     for (String course : student.getCoursesEnrolled()) {
         System.out.println(course);
     }
 }
}
