package sis;

public class EnrollmentManager {
 public void enrollStudentInCourse(Student student, Course course) {
     course.addStudent(student);
 }
}
