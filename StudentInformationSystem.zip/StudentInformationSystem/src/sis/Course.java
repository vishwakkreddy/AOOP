package sis;

import java.util.ArrayList;
import java.util.List;

public class Course {
    private String courseName;
    private String courseID;
    private List<Student> enrolledStudents;  // List to store enrolled students

    public Course(String courseName, String courseID) {
        this.courseName = courseName;
        this.courseID = courseID;
        this.enrolledStudents = new ArrayList<>();  // Initialize the list here
    }

    public void addStudent(Student student) {
        enrolledStudents.add(student);  // Add student to the list
    }

    public String getCourseName() {
        return courseName;
    }

    public String getCourseID() {
        return courseID;
    }

    public List<Student> getEnrolledStudents() {
        return enrolledStudents;
    }
}


