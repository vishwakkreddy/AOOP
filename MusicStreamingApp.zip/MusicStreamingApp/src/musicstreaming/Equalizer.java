package musicstreaming;

public class Equalizer extends MusicDecorator {
    public Equalizer(MusicSource musicSource) {
        super(musicSource);
    }

    @Override
    public void playMusic() {
        super.playMusic();
        System.out.println("Equalizer: Enhancing sound quality.");
    }
}
