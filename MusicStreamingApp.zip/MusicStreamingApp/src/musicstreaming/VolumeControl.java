package musicstreaming;

public class VolumeControl extends MusicDecorator {
    public VolumeControl(MusicSource musicSource) {
        super(musicSource);
    }

    @Override
    public void playMusic() {
        super.playMusic();
        System.out.println("Volume Control: Adjusting volume.");
    }
}
