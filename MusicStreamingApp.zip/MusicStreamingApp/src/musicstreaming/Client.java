package musicstreaming;

public class Client {
    public static void main(String[] args) {
        // Adapter Pattern
        MusicSource localMusic = new LocalFileAdapter(new LocalFilePlayer());
        MusicSource onlineMusic = new OnlineStreamingAdapter(new OnlineStreamingPlayer());
        MusicSource radioMusic = new RadioAdapter(new RadioPlayer());

        // Bridge Pattern
        MusicPlayer player = new AdvancedMusicPlayer(localMusic);
        player.play();

        System.out.println();

        player = new AdvancedMusicPlayer(onlineMusic);
        player.play();

        System.out.println();

        player = new AdvancedMusicPlayer(radioMusic);
        player.play();

        System.out.println();

        // Decorator Pattern
        MusicSource enhancedLocalMusic = new Equalizer(new VolumeControl(localMusic));
        MusicPlayer enhancedPlayer = new AdvancedMusicPlayer(enhancedLocalMusic);
        enhancedPlayer.play();
    }
}
