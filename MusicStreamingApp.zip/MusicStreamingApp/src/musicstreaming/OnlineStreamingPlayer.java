package musicstreaming;

public class OnlineStreamingPlayer {
    public void streamMusic(String url) {
        System.out.println("Streaming music from: " + url);
    }
}

class OnlineStreamingAdapter implements MusicSource {
    private OnlineStreamingPlayer onlinePlayer;

    public OnlineStreamingAdapter(OnlineStreamingPlayer onlinePlayer) {
        this.onlinePlayer = onlinePlayer;
    }

    @Override
    public void playMusic() {
        onlinePlayer.streamMusic("https://example.com/stream");
    }
}
