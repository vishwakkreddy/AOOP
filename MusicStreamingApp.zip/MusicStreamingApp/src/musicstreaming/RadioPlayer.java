package musicstreaming;

public class RadioPlayer {
    public void playRadio(String station) {
        System.out.println("Playing radio station: " + station);
    }
}

class RadioAdapter implements MusicSource {
    private RadioPlayer radioPlayer;

    public RadioAdapter(RadioPlayer radioPlayer) {
        this.radioPlayer = radioPlayer;
    }

    @Override
    public void playMusic() {
        radioPlayer.playRadio("Cool FM");
    }
}

