package musicstreaming;

public class LocalFilePlayer {
    public void playFromFile(String fileName) {
        System.out.println("Playing local file: " + fileName);
    }
}

class LocalFileAdapter implements MusicSource {
    private LocalFilePlayer localFilePlayer;

    public LocalFileAdapter(LocalFilePlayer localFilePlayer) {
        this.localFilePlayer = localFilePlayer;
    }

    @Override
    public void playMusic() {
        localFilePlayer.playFromFile("MySong.mp3");
    }
}
